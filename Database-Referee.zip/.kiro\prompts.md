# AI Prompts Used During Development

## Initial Project Prompt

```
You are a senior full-stack developer and technical writer. Build a complete beginner-friendly web project for "Kiro Week 6 Challenge – The Referee".

Project title: "Database Referee – MySQL vs MongoDB"

Objective: Create a decision-support tool that compares two options and explains trade-offs instead of giving a single answer.

Functional requirements:
- User inputs: Project size, Data type, Scalability need, Experience level
- Output: Pros/cons for both databases, trade-offs section, neutral recommendation
- Never say "this is the best option"

Technical requirements:
- Tech stack: HTML, CSS, JavaScript only
- No backend, no frameworks
- Clean UI and readable code
- Use simple if-else logic
- Add comments for beginners
```

## Follow-up Prompts Used

### Code Structure Refinement
```
Make the JavaScript more beginner-friendly with extensive comments explaining each function and decision-making logic.
```

### UI/UX Enhancement
```
Improve the visual design with better color scheme, animations, and responsive layout that works well on mobile devices.
```

### Content Balancing
```
Ensure the database comparison is truly neutral - avoid favoring either MySQL or MongoDB. Focus on educational trade-offs.
```

### Code Quality
```
Add proper error handling, input validation, and smooth user interactions. Make sure the code follows best practices.
```

## Prompt Engineering Insights

### What Worked Well
- **Specific Requirements**: Clear functional and technical requirements led to focused development
- **Beginner Focus**: Emphasizing beginner-friendliness resulted in well-commented, educational code
- **Neutral Stance**: Explicitly requesting neutrality prevented biased recommendations
- **No Framework Constraint**: Forced clean, vanilla JavaScript that's easier to understand

### Iterative Improvements
- Started with basic functionality, then enhanced UI/UX
- Added responsive design considerations after initial layout
- Refined the decision logic to be more balanced and educational
- Enhanced code comments for better learning experience

### Key Prompt Patterns
1. **Role Definition**: "You are a senior full-stack developer and technical writer"
2. **Clear Constraints**: "HTML, CSS, JavaScript only - no frameworks"
3. **Specific Deliverables**: Listed exact files and content needed
4. **Quality Requirements**: "beginner-friendly", "clean UI", "readable code"
5. **Behavioral Guidelines**: "Never say this is the best option"